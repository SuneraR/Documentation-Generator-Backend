export default function Divider(){
    return <hr className="border-t border-2 border-[#343e4d] max-w-7xl my-8 mx-auto" />;
}